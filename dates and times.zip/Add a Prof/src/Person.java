import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;

class Person {
    private String firstName, lastName;
    private LocalDate dob;
    private String hometown;
    private List<Address> addresses;

    public Person() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getDob() {
        return dob;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", dob=" + dob +
                ", homwtown='" + hometown + '\'' +
                ", addresses=" + addresses +
                '}';
    }

    public int gerAge() {
        return Calendar.getInstance().get(Calendar.YEAR) - dob.getYear();
    }

    public void setDateOfBirth(String dob) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("YYYY-MM-DD");
        this.dob = LocalDate.parse(dob, dtf);
    }
}