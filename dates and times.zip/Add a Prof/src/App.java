import java.util.ArrayList;
import java.util.Random;

public class App {
          
        public static void main (String [] args) {
                
                StudentAthlete studentAthelete = new StudentAthlete();
                
                
                Sports sport = Sports.values()[new Random().nextInt(Sports.values().length)];;
                
                studentAthelete.setStudent_name("Danny Obara");
                studentAthelete.setAge(19);
                studentAthelete.setAddress("East Stroudsburg, PA");
                studentAthelete.setPhone_no(2019945482);
                studentAthelete.setSports("" + sport);
                studentAthelete.setStudentId(109101);
                studentAthelete.setRanking(10);
                
               
                
                System.out.println("Student Athelete: ");
                System.out.println(studentAthelete.toString());
                
              
        }
}