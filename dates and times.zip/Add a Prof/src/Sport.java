enum Sports{
                Baseball,
                Basketball,
                Tennis,
                Cricket,
                Swimming,
                Ice_Skating
        }