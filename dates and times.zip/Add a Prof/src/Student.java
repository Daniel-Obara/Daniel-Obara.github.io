public class Student {
        protected int studentId;
        protected String student_name;
        protected int age;
        protected String address;
        protected int phone_no;
        
        public Student() {
                
        }
        
        public Student(int studentId, String student_name, int age, String address, int phone_no) {
                this.studentId = studentId;
                this.student_name = student_name;
                this.age = age;
                this.address = address;
                this.phone_no = phone_no;
        }

        public int getStudentId() {
                return studentId;
        }
        public void setStudentId(int studentId) {
                this.studentId = studentId;
        }
        public String getStudent_name() {
                return student_name;
        }
        public void setStudent_name(String student_name) {
                this.student_name = student_name;
        }
        public int getAge() {
                return age;
        }
        public void setAge(int age) {
                this.age = age;
        }
        public String getAddress() {
                return address;
        }
        public void setAddress(String address) {
                this.address = address;
        }
        public int getPhone_no() {
                return phone_no;
        }
        public void setPhone_no(int phone_no) {
                this.phone_no = phone_no;
        }
}