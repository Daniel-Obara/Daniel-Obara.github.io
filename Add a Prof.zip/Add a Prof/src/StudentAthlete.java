public class StudentAthlete extends Student{
        
        protected String sports;
        protected int ranking;
        
        public StudentAthlete() {
                super();
                // TODO Auto-generated constructor stub
        }
        
        public StudentAthlete(int studentId, String student_name, int age, String address, int phone_no, String sports, int ranking) {
                super(studentId, student_name, age, address, phone_no);
                this.sports = sports;
                this.ranking = ranking;
                // TODO Auto-generated constructor stub
        }
        
        public String getSports() {
                return sports;
        }
        public void setSports(String sports) {
                this.sports = sports;
        }
        public int getRanking() {
                return ranking;
        }
        public void setRanking(int ranking) {
                this.ranking = ranking;
        }
        
        public String toString() {
                String string = "";
                string += "Student ID: " + this.studentId;
                string +="\nStudent Name: " + this.student_name;
                string +="\nAge: " + this.age;
                string +="\nAddress: " + this.address;
                string +="\nPhone No: " + this.phone_no;
                string += "\nSport: " + this.sports;
                string += "\nRanking: " + this.ranking;
                
                return string;
        }
}