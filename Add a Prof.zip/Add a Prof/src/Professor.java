import java.util.ArrayList;

public class Professor {
        protected int professorId;
        protected String name;
        protected int phone_no;
        protected String address;
        protected ArrayList<String> courses_teaching = new ArrayList<String>();
        
        public int getProfessorId() {
                return professorId;
        }
        
        public void setProfessorId(int professorId) {
                this.professorId = professorId;
        }
        
        public String getName() {
                return name;
        }
        
        public void setName(String name) {
                this.name = name;
        }
        
        public int getPhone_no() {
                return phone_no;
        }
        
        public void setPhone_no(int phone_no) {
                this.phone_no = phone_no;
        }
        
        public String getAddress() {
                return address;
        }
        
        public void setAddress(String address) {
                this.address = address;
        }
        
        public ArrayList<String> getCourses_teaching() {
                return courses_teaching;
        }
        
        public void setCourses_teaching(ArrayList<String> courses_teaching) {
                this.courses_teaching = courses_teaching;
        }
        
        public String toString() {
                String string = "";
                string += "Professor ID: " + this.professorId;
                string +="\nProfessor Name: " + this.name;
                string +="\nAddress: " + this.address;
                string +="\nPhone No: " + this.phone_no;
                string += "\nCourses Currently Teaching: ";
                
                for (int i = 0; i < this.courses_teaching.size(); i++) {
                        string += "\n" + courses_teaching.get(i);
                }
                
                return string;
        }
}