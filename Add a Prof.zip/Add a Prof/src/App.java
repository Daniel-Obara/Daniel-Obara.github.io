import java.util.ArrayList;
import java.util.Random;

public class App {
          
        public static void main (String [] args) {
                
                StudentAthlete studentAthelete = new StudentAthlete();
 Professor professor = new Professor();
                
                ArrayList<String> courses = new ArrayList<String>();
                courses.add("IST 240");
                courses.add("IST 140");
                courses.add("IST 242");
                
                Sports sport = Sports.values()[new Random().nextInt(Sports.values().length)];;
                
                studentAthelete.setStudent_name("Danny Obara");
                studentAthelete.setAge(19);
                studentAthelete.setAddress("East Stroudsburg, PA");
                studentAthelete.setPhone_no(2019945482);
                studentAthelete.setSports("" + sport);
                studentAthelete.setStudentId(109101);
                studentAthelete.setRanking(10);
                
                professor.setName("Shawn E. Smith");
                professor.setAddress("State College, PA");
                professor.setPhone_no(00000000);
                professor.setProfessorId(100);
                professor.setCourses_teaching(courses);
                
                System.out.println("Student Athelete: ");
                System.out.println(studentAthelete.toString());
                
                System.out.println("\nProfessor: ");
                System.out.println(professor.toString());

        }
}