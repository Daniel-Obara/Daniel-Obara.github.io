public class App {

   public static void main(String[] args) {
       Person p = new Person("Daniel", "Obara", 19, "East Stroudsburg");
       System.out.println(p.getInfo());
       Student s = new Student("Daniel", "Obara", 19, "East Stroudsburg", "128468", "IST: Enterprise Technology Integration", 3.05);
       System.out.println(s.getInfo());
       StudentAthlete ath = new StudentAthlete("Daniel", "Obara", 19, "East Stroudsburg", "128468", "IST: Enterprise Technology Integration", 3.05, "Basketball", 11);
       System.out.println(ath.getInfo());


   }
}