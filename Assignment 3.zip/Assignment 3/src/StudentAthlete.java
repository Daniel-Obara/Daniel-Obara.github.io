public class StudentAthlete extends Student {

   public String sport;
   public int ranking;

   public StudentAthlete(String fname, String lname, int age, String htown, String id, String major, double d,String sport,int ranking) {
       super(fname, lname, age, htown, id, major, d);
       this.sport=sport;
       this.ranking=ranking;
   }
   @Override
   public String getInfo() {
       return "The sport played is "+this.sport+", The ranking is "+this.ranking+" out of 100";
   }
}