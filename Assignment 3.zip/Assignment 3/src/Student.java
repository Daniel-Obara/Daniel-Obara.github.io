public class Student extends Person {
   public String id;
   public String major;
   public double GPA;

   public Student(String fname, String lname, int age, String htown, String id, String major, double gpa) {
       super(fname, lname, age, htown);
       this.id = id;
       this.major = major;
       this.GPA = gpa;
   }
   @Override
public String getInfo() {
   return "The ID # is "+this.id+", The Major is "+this.major+", and the GPA is "+this.GPA;
}
}