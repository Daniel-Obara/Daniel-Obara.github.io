public class Person {

   public String firstName;
   public String lastName;
   public int age;
   public String hometown;
  
   public Person(String fname,String lname,int age,String htown) {
       this.firstName=fname;
       this.lastName=lname;
       this.age=age;
       this.hometown=htown;
   }
  
   public String getInfo() {
       return this.firstName+" " +this.lastName+" is "+this.age+" years old and from "+this.hometown;
   }
}