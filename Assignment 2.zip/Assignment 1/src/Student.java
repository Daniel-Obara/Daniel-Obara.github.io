import java.util.ArrayList;
import java.util.List;

public class Student {
   private String givenName ;
   private String familyName ;
   private int age ;
   private double gpa ;
   private List<Course> courseList;
   public Student(String givenName, String familyName, int age, double gpa) {
      
       this.givenName = givenName;
       this.familyName = familyName;
       this.age = age;
       this.gpa = gpa;
       
       courseList = new ArrayList<>();
   }
   public String getgivenName() {
       return givenName;
   }
   public void setgivenName(String givenName) {
       this.givenName = givenName;
   }
   public String getfamilyName() {
       return familyName;
   }
   public void setfamilyName(String familyName) {
       this.familyName = familyName;
   }
   public int getAge() {
       return age;
   }
   public void setAge(int age) {
       this.age = age;
   }
   public double getGpa() {
       return gpa;
   }
   public void setGpa(double gpa) {
       this.gpa = gpa;
   }
   public List<Course> getCourseList() {
       return courseList;
   }
   public void setCourseList(List<Course> courseList) {
       this.courseList = courseList;
   }
   public void addCourse(Course obj) {
       courseList.add(obj);
   }
   public String toString() {
       return "" + givenName + " " + familyName + " with a gpa of "+ gpa + "";
   }
  
}