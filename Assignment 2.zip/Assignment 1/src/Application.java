
public class Application {

   public static void main(String[] args) {
      
       Student s1 = new Student("Danny", "Obara", 19, 3.02);
       Student s2 = new Student("Ryan", "Edery", 19, 3.27);
       Student s3 = new Student("Jon", "Kroon", 19, 3.5);
       Student low, high;
       if(s1.getGpa() < s2.getGpa()) {
           if(s1.getGpa() < s3.getGpa()) {
               low = s1 ;
           }
           else {
               low = s3 ;
           }
       }
       else {
           if(s2.getGpa() < s3.getGpa()) {
               low = s2 ;
           }
           else {
               low = s3 ;
           }
       }
       if(s1.getGpa() > s2.getGpa()) {
           if(s1.getGpa() > s3.getGpa()) {
               high = s1 ;
           }
           else {
               high = s3 ;
           }
       }
       else {
           if(s2.getGpa() > s3.getGpa()) {
               high = s2 ;
           }
           else {
               high = s3 ;
           }
       }
       System.out.println("Student with lowest GPA is " + low);
       System.out.println("Student with highest GPA is " + high);
       
       Course c1 = new Course("IST", "240", 5);
       Course c2 = new Course("IST", "220", 1);
       Course c3 = new Course("IT", "130", 5);
       Course c4 = new Course("Math", "140", 4);
       Course c5 = new Course("Engineering", "101", 4);
       Course c6 = new Course("Cybersecurity", "242", 4);
       Course c7 = new Course("Russian Film Studies", "12", 6);
       
       s1.addCourse(c1);
       s1.addCourse(c2);
       s1.addCourse(c3);
       
       s2.addCourse(c6);
       s2.addCourse(c7);
       s2.addCourse(c2);
       
       s3.addCourse(c4);
       s3.addCourse(c5);
      
       System.out.println(s1.getgivenName()+" "+s1.getfamilyName()+" is taking: ");
       for(Course course: s1.getCourseList())
           System.out.println(course);
       System.out.println(s2.getgivenName()+" "+s2.getfamilyName()+" is taking: ");
       for(Course course: s2.getCourseList())
           System.out.println(course);
       System.out.println(s3.getgivenName()+" "+s3.getfamilyName()+" is taking: ");
       for(Course course: s3.getCourseList())
           System.out.println(course);
   }

}