
public class Course {
	
	   private String name;
	   private String section;
	   private int creditHours;

	   public Course(String name, String section, int creditHours) {
	       this.name = name;
	       this.section = section;
	       this.creditHours = creditHours;
	   }

	   public String getName() {
	       return name;
	   } 

	   public String getSection() {
	       return section;
	   }

	   public int getCreditHours() {
	       return creditHours;
	   }

	   @Override
	   public String toString() {
	       return name+" "+section;
	   }
	}

