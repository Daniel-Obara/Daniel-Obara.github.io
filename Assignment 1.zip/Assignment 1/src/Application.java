
public class Application {

   public static void main(String[] args) {
      
       Student s1 = new Student("Danny", "Obara", 19, 3.02);
       Student s2 = new Student("Ryan", "Edery", 19, 3.27);
       Student s3 = new Student("Jon", "Kroon", 19, 3.5);
       Student low, high;
       if(s1.getGpa() < s2.getGpa()) {
           if(s1.getGpa() < s3.getGpa()) {
               low = s1 ;
           }
           else {
               low = s3 ;
           }
       }
       else {
           if(s2.getGpa() < s3.getGpa()) {
               low = s2 ;
           }
           else {
               low = s3 ;
           }
       }
       if(s1.getGpa() > s2.getGpa()) {
           if(s1.getGpa() > s3.getGpa()) {
               high = s1 ;
           }
           else {
               high = s3 ;
           }
       }
       else {
           if(s2.getGpa() > s3.getGpa()) {
               high = s2 ;
           }
           else {
               high = s3 ;
           }
       }
       System.out.println("Student with lowest GPA is " + low);
       System.out.println("Student with highest GPA is " + high);
   }

}