public enum AddressType {

   LOCAL, PERMANENT

}