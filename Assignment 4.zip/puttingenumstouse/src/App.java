
import java.util.ArrayList;
import java.util.List;


public class App {
   public static void main(String[] args) {

   
   List<Address> address = new ArrayList<Address>();
   address.add(new Address("340 East Beaver Ave,", "State College", "PA", 16801, AddressType.LOCAL));
   address.add(new Address("Poconos", "PA", "USA", 18328, AddressType.PERMANENT));
  
   Person p1 = new Student("Daniel", "Obara", 19, "State College", address, "128468", "IST", 3.1);

   
   List<Address> address1 = new ArrayList<Address>();
   address1.add(new Address("340 East Beaver Ave,", "State College", "PA", 16801, AddressType.LOCAL));
   address1.add(new Address("Philly", "PA", "USA", 11212, AddressType.PERMANENT));
   
   Person p2 = new StudentAthlete("Ryan", "Edery", 20, "State College", address1, "11111", "Cyber Security", 3.2, "Golf");

   
   System.out.println("Person 1 details: ");
   System.out.println(p1.toString());
   System.out.println("\nPerson 2 details: ");
   System.out.println(p2.toString());
   }
   }